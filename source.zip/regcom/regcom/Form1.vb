﻿Imports System.IO
Public Class Form1
    'ocx-library-registrar
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'waived @ github.com
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim fbd As New FolderBrowserDialog

        If fbd.ShowDialog = DialogResult.OK Then
            lbPath.Text = fbd.SelectedPath

            System.Threading.ThreadPool.QueueUserWorkItem(Sub() get_ocx())
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Button1.Enabled = False

        If DataGridView1.RowCount > 0 Then
            System.Threading.ThreadPool.QueueUserWorkItem(Sub() reg_ocx())
        End If
    End Sub

    Private Sub get_ocx()
        CheckForIllegalCrossThreadCalls = False

        Button1.Enabled = False
        Button2.Enabled = False

        Try
            If DataGridView1.Rows.Count > 0 Then
                DataGridView1.Rows.Clear()
            End If

            DataGridView1.ScrollBars = ScrollBars.None

            Dim files As String() = Directory.GetFiles(lbPath.Text, "*.ocx")

            DataGridView1.Rows.Clear()

            For Each file As String In files
                Dim fileName As String = Path.GetFileName(file)
                DataGridView1.Rows.Add(fileName, "")
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error!")
        End Try

        DataGridView1.ScrollBars = ScrollBars.Both

        Button2.Enabled = True
        Button1.Enabled = True
    End Sub

    Private Sub reg_ocx()
        CheckForIllegalCrossThreadCalls = False

        Button1.Enabled = False
        Button2.Enabled = False

        Try
            For Each row As DataGridViewRow In DataGridView1.Rows

                If Not row.IsNewRow Then

                    Dim ocxlib As String = Path.Combine(lbPath.Text, row.Cells(0).Value.ToString())

                    Try
                        Shell("regsvr32 " + Chr(34) + ocxlib + Chr(34) + " /s")

                        row.Cells(1).Value = "REGISTERED"
                    Catch ex As Exception
                        row.Cells(1).Value = "ERROR!"
                    End Try

                End If

            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error!")
        End Try

        DataGridView1.ScrollBars = ScrollBars.Both

        Button2.Enabled = True
        Button1.Enabled = True
    End Sub
End Class
